import React, { Component } from 'react'

class NotFoundPage extends Component {
  render () {
    return (
      <div>
        <h3>This page is not available.</h3>
      </div>
    )
  }
}

export default NotFoundPage
